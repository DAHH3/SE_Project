<?php
 ?><?php /**PATH /Users/hbixler/Desktop/SE/SE_Project/room-reservation/resources/views/layout.blade.php ENDPATH**/ ?>