<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="view" content = "width=device-width, initial-scale=1">
  <title>Reservation Information</title>
  <link rel="stylesheet" href="../../css/reservation.css">
  <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet'>
</head>

<style>
.btn1{
	margin-right:50px
}
</style>


<body>

<div class = "header">
  <h1>The Continental Library</h1>
</div>

<div class="body">
  <h2>Reservation Information</h2>

  <?php if($reservation): ?>

    <div class="container">
      <table>
        <tr>
          <th colspan="2">Reservation</th>
        </tr>
        <tr>
          <td>Room:</td>
          <td><?php echo e($reservation->room_id); ?></td>
        </tr>
        <tr>
          <td>Date:</td>
          <td><?php echo e($reservation->date); ?></td>
        </tr>
        <tr>
          <td>Time:</td>
          <td><?php echo e($reservation->start_time); ?> to <?php echo e($reservation->end_time); ?></td>
        </tr>
      </table>
    </div>
  
    <!--  /*TODO: Add Delete Message to delete button*/-->
    <form action="/reservations/delete" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="reservation_id" value="<?php echo e($reservation->id); ?>">
      <button class = "button button" type="submit">
        Delete
      </button>
      <button class = "button button" onclick="window.location.href =` <?php echo e(route('startPage')); ?> `">
        Home
      </button>
    </form>
  <?php endif; ?>
  <?php if(!$reservation): ?>
    <p>No matching reservations could be found.</p>
    <button class = "button button" onclick="window.location.href =` <?php echo e(route('startPage')); ?> `">
      Home
    </button>
  <?php endif; ?>
</div>


</body>
</html>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hbixler/Desktop/SE/SE_Project/room-reservation/resources/views/reservationInformation.blade.php ENDPATH**/ ?>