<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="view" content = "width=device-width, initial-scale=1">
    <title>Room Selection</title>
    <link rel="stylesheet" href="../../css/reservation.css">
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet'>
</head>
<body>

<div class = "header">
    <h1>The Continental Library</h1>
</div>

<div class = "body">
    <h2>Select Room</h2>

    <?php if(count($rooms) == 0): ?>
        <p>There were no rooms matching your search.</p>
    <?php endif; ?>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action ="/reservations/create" method="post" class="container">
        <?php echo csrf_field(); ?>
            <input type="hidden" name="room_id" value="<?php echo e($room->id); ?> ">
            <input type="hidden" name="date" value="<?php echo e($date); ?>">
            <input type="hidden" name="start_time" value="<?php echo e($start_time); ?>">
            <input type="hidden" name="end_time" value="<?php echo e($end_time); ?>">
            <table>
                <tr>
                    <th>Room <?php echo e($room->id); ?></th>
                </tr>
                <tr>
                    <td>Capacity: <?php echo e($room->capacity); ?></td>
                </tr>
                <?php if($room->wifi): ?>
                    <tr>
                        <td>&#10003; Wifi Access</td>
                    </tr>
                <?php endif; ?>
                <?php if($room->handicap_accessible): ?>
                    <tr>
                        <td>&#10003; Handicap Accessible</td>
                    </tr>
                <?php endif; ?>
                <?php if($room->whiteboard): ?>
                    <tr>
                        <td>&#10003; Whiteboard Available</td>
                    </tr>
                <?php endif; ?>
            </table>
            <button class = "button button" type="submit">
                Book
            </button>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</body>
</html><?php /**PATH /Users/hbixler/Desktop/SE/SE_Project/room-reservation/resources/views/roomSelect.blade.php ENDPATH**/ ?>